#ifndef SOUM_H
#define SOUM_H
#include "currency.cpp"
#include <string>

class Soum:public Currency{
    private:
        std::string name = "Soum";

    public:
        Soum();
        Soum(double x);

        void print();
        void add(Currency& x);
        void subtract(Currency& x);
        bool isEqual(Currency& x);
        bool isGreater(Currency& x);
};

Soum::Soum() {
}

Soum::Soum(double x) 
    : Currency(x) {
}

// Prints the whole, fraction, and name values of the object
// Pre:
// Post:
// Returns:
void Soum::print() {
        std::cout << whole << "." << fraction << " " << name;
}

// Adds the value of the given currency object to the one being called.
// Throws an exception if the input is not in Soums
// Pre:
//    x - a reference to another currency object
// Post:
//    whole - value of the current object
//    fraction - value of the current object
// Returns:
void Soum::add(Currency& x){
    try {
        if (typeid(x) == typeid(Soum)){
            Currency::add(x);
        }else{
            throw std::invalid_argument("Invalid addition, must be same currency");
        }
    } catch (const std::exception) {
        std::cerr << "Invalid addition" << '\n';
        return;
    }
}

// Subtracts the value of the given currency object from the one being called
// Throws an exception if the input is not in Soums
// Pre:
//    x - a reference to another currency object
// Post:
//    whole - value of the current object
//    fraction - value of the current object
// Returns:
void Soum::subtract(Currency& x) {
    try {
        if (typeid(x) == typeid(Soum)){
            Currency::subtract(x);
        }else{
            throw std::invalid_argument("Invalid subtraction, must be same currency");
        }
    } catch (const std::exception) {
        std::cerr << "Invalid subtraction" << '\n';
        return;
    }
}

// Compares the whole and fraction values for equality
// Throws an exception if the input is not in Soums
// Pre:
//    x - A reference to another currency object
// Post:
// Returns:
//    bool - true if the two objects are equal, false otherwise
bool Soum::isEqual(Currency& x) {
    try {
        if (typeid(x) == typeid(Soum)){
            return Currency::isEqual(x);
        }else{
            throw std::invalid_argument("Invalid input, must be same currency");
        }
    } catch (const std::exception) {
        std::cerr << "Invalid input" << '\n';
        return false;
    }
}

// Compares the values of the given currency object
// Throws an exception if the input is not in Soums
// Pre:
//    x - A reference to another currency object
// Post:
// Returns:
//    bool - true if the current object is greater than the given object, false otherwise
bool Soum::isGreater(Currency& x) {
    try {
        if (typeid(x) == typeid(Soum)){
            return Currency::isGreater(x);
        }else{
            throw std::invalid_argument("Invalid input, must be same currency");
        }
    } catch (const std::exception) {
        std::cerr << "Invalid input" << '\n';
        return false;
    }
}

#endif