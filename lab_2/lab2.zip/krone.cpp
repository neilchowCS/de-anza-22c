#ifndef KRONE_H
#define KRONE_H
#include "currency.cpp"
#include <string>

class Krone:public Currency{
    private:
        std::string name = "Krone";

    public:
        Krone();
        Krone(double x);

        void print();
        void add(Currency& x);
        void subtract(Currency& x);
        bool isEqual(Currency& x);
        bool isGreater(Currency& x);
};

Krone::Krone() {
}

Krone::Krone(double x) 
    : Currency(x) {
}

// Prints the whole, fraction, and name values of the object
// Pre:
// Post:
// Returns:
void Krone::print() {
        std::cout << whole << "." << fraction << " " << name;
}

// Adds the value of the given currency object to the one being called.
// Throws an exception if the input is not in Krones
// Pre:
//    x - a reference to another currency object
// Post:
//    whole - value of the current object
//    fraction - value of the current object
// Returns:
void Krone::add(Currency& x) {
    try {
        if (typeid(x) == typeid(Krone)){
            Currency::add(x);
        }else{
            throw std::invalid_argument("Invalid addition, must be the same currency");
        }
    } catch (const std::exception) {
        std::cerr << "Invalid addition" << '\n';
        return;
    }
}

// Subtracts the value of the given currency object from the one being called
// Throws an exception if the input is not in Krones
// Pre:
//    x - a reference to another currency object
// Post:
//    whole - value of the current object
//    fraction - value of the current object
// Returns:
void Krone::subtract(Currency& x) {
    try {
        if (typeid(x) == typeid(Krone)){
            Currency::subtract(x);
        }else{
            throw std::invalid_argument("Invalid subtraction, must be the same currency");
        }
    } catch (const std::exception) {
        std::cerr << "Invalid subtraction" << '\n';
        return;
    }
}

// Compares the whole and fraction values for equality
// Throws an exception if the input is not in Krones
// Pre:
//    x - A reference to another currency object
// Post:
// Returns:
//    bool - true if the two objects are equal, false otherwise
bool Krone::isEqual(Currency& x) {
    try {
        if (typeid(x) == typeid(Krone)){
            return Currency::isEqual(x);
        }else{
            throw std::invalid_argument("Invalid input, must be the same currency");
        }
    } catch (const std::exception) {
        std::cerr << "Invalid input" << '\n';
        return false;
    }
}

// Compares the values of the given currency object
// Throws an exception if the input is not in Krones
// Pre:
//    x - A reference to another currency object
// Post:
// Returns:
//    bool - true if the current object is greater than the given object, false otherwise
bool Krone::isGreater(Currency& x) {
    try {
        if (typeid(x) == typeid(Krone)){
            return Currency::isGreater(x);
        }else{
            throw std::invalid_argument("Invalid input, must be the same currency");
        }
    } catch (const std::exception) {
        std::cerr << "Invalid input" << '\n';
        return false;
    }
}

#endif